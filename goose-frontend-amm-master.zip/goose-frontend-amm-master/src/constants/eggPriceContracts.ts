const priceContracts: {cakeAddress: string, busdAddress: string, lpAddress:string} = {
  cakeAddress: '0xf952fc3ca7325cc27d15885d37117676d25bfda6',
  busdAddress: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
  lpAddress: '0x19e7cbecdd23a16dfa5573df54d98f7caae03019'
}

export default priceContracts